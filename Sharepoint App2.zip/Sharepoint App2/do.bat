@echo off

if "%~1" == "" goto usage
if not exist %1.iashell goto file_not_found

call %INFOARCHIVE%\bin\iashell --cmdfile %1.iashell --cmdfile_echo
goto end

:file_not_found
echo cmdfile not found: %1.iashell
goto end

:usage
echo USAGE:   %0 cmdfile
echo Example: %0 search-config
goto end

:end