@echo off
call ..\..\..\bin\iashell --cmdfile install.iashell --cmdfile_echo
